import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class lab4Beziera
{
    private Punkt punkty[][][];
    private FileWriter Filez;
    private File File;
    private int ilosc;

    public lab4Beziera(String File, String Filez)
    {
        this.File = new File(File);
        try {
            this.Filez = new FileWriter(Filez);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void Wspolrzedne()
    {
        try {
            Scanner Scanner = new Scanner(File);
            String Plat = Scanner.next();
            ilosc = Integer.parseInt(Plat);
            punkty = new Punkt[ilosc][4][4];
            for(int i = 0; i < ilosc; i++)
            {
                for(int j = 0; j < 4; j++)
                {
                    for(int k = 0; k < 4; k++)
                    {
                        punkty[i][j][k] = new Punkt(Double.parseDouble(Scanner.next()), Double.parseDouble(Scanner.next()), Double.parseDouble(Scanner.next()));
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static double Silnia(int n)
    {
        long x = 1;
        for (int i = 2; i <= n; i++)
        {
            x = x * i;
        }
        return x;
    }

    public static double Bernstein(int i, int n, double x)
    {
        return (Silnia(n) / (Silnia(n - i) * Silnia(i))) * (Math.pow((1 -x), (n - i))) * (Math.pow(x, i));
    }


    public void Punkt3() throws IOException
    {
        double xx;
        double yy;
        double zz;

        try {
            Filez.write("x, y, z" + System.lineSeparator());
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        for(int i = 0; i < ilosc; i++)
        {
            for(double j = 0.0; j <= 1.0; j += 0.03)
            {
                for(double k = 0.0; k <= 1.0; k += 0.03)
                {
                    xx = 0;
                    yy = 0;
                    zz = 0;
                    for(int l = 0; l < 4; l++)
                    {
                        for(int m = 0; m < 4; m++)
                        {
                            xx += punkty[i][m][l].x * Bernstein(m, 3, k) * Bernstein(l, 3, j);
                            yy += punkty[i][m][l].y * Bernstein(m, 3, k) * Bernstein(l, 3, j);
                            zz += punkty[i][m][l].z * Bernstein(m, 3, k) * Bernstein(l, 3, j);
                        }
                    }
                    Filez.write(xx + ", " + yy + ", " + zz + System.lineSeparator());
                }
            }
        }
    }
    
    
    public static void main(String args[]) throws IOException
    {
        lab4Beziera Czajnik = new lab4Beziera("Czajnik.txt", "CzajnikPo.txt");
        Czajnik.Wspolrzedne();
        Czajnik.Punkt3();

        lab4Beziera Filizanka = new lab4Beziera("Filizanka.txt", "FilizankaPo.txt");
        Filizanka.Wspolrzedne();
        Filizanka.Punkt3();

        lab4Beziera Lyzeczka = new lab4Beziera("Lyzeczka.txt", "LyzeczkaPo.txt");
        Lyzeczka.Wspolrzedne();
        Lyzeczka.Punkt3();
    }


    public class Punkt
    {
        public double x = 0;
        public double y = 0;
        public double z = 0;

        public Punkt(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }
}